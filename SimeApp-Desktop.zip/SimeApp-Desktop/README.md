# SIME - App Desktop (Windows Forms)

Sistema de Monitoramento de Erros Industriais - versão computador.

## Como rodar
1. Abra o `SimeDesktop.sln` no Visual Studio 2022 (carga de trabalho "Desenvolvimento para desktop com .NET"). O projeto usa .NET 7 (`net7.0-windows`).
2. Rode o `sime.sql` no phpMyAdmin do FreeDB (só na primeira vez).
3. Em `SimeDesktop/Services/SimeService.cs`, troque `SEU_USUARIO` e `SUA_SENHA` pelos dados do FreeDB.
4. Aperte F5.

## Usuários
| Usuário | Senha | Perfil |
|---|---|---|
| operador | 123 | Operador |
| operador2 | 123 | Operador |
| supervisor | 123 | Supervisor |

## Organização
- `Models/` - Ocorrencia, Usuario, ErrosMes
- `Services/SimeService.cs` - login e acesso ao banco (Inserir, Listar, Localizar, ErrosPorMes, AlterarStatus)
- **FormLogin:** usuário e senha.
- **FormCadastro:** (Operador) escolhe a máquina e digita o erro. Nome, data/hora e status "pendente" são automáticos.
- **FormPrincipal:** (Supervisor) aba Dashboard (totais + erros por mês) e aba Ocorrências (busca por máquina + lista).
- **FormDetalhes:** mostra a ocorrência e permite alterar o status (dois cliques na linha ou botão "Ver Detalhes").

## Sincronização
O app Mobile usa o mesmo banco. Registre um erro no Mobile e clique em "Atualizar" aqui: a ocorrência aparece. Mude o status aqui e atualize a lista no Mobile.
