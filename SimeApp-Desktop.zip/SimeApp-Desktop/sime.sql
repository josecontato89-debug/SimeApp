-- Execute no phpMyAdmin do FreeDB (https://phpmyadmin.freedb.tech) para criar a tabela do SIME.
CREATE TABLE IF NOT EXISTS `sime` (
  `id` int NOT NULL AUTO_INCREMENT,
  `colaborador` varchar(200) NOT NULL,
  `perfil_usuario` varchar(20) DEFAULT 'operador',
  `maquina` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT 'pendente',
  `erro` varchar(200) NOT NULL,
  `data_hora` datetime NOT NULL,
  PRIMARY KEY (`id`)
);
