namespace SimeDesktop.Models
{
    public class ErrosMes
    {
        public string Mes { get; set; }
        public int Quantidade { get; set; }
        public int Pendentes { get; set; }
    }
}
