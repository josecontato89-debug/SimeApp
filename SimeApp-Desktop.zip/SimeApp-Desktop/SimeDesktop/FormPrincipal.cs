using SimeDesktop.Models;
using SimeDesktop.Services;

namespace SimeDesktop
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal(Usuario usuario)
        {
            InitializeComponent();
            lblSupervisor.Text = "Supervisor: " + usuario.Nome;
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            CarregarDashboard();
            CarregarLista();
        }

        private void CarregarDashboard()
        {
            try
            {
                SimeService service = new SimeService();

                List<Ocorrencia> ocorrencias = service.Listar();
                int pendentes = 0;
                int resolvidos = 0;
                foreach (Ocorrencia o in ocorrencias)
                {
                    if (o.Status == "pendente")
                        pendentes++;
                    else
                        resolvidos++;
                }
                lblTotal.Text = ocorrencias.Count.ToString();
                lblPendentes.Text = pendentes.ToString();
                lblResolvidos.Text = resolvidos.ToString();

                dgvMeses.DataSource = service.ErrosPorMes();
                dgvMeses.Columns["Mes"].HeaderText = "Mês";
                dgvMeses.Columns["Quantidade"].HeaderText = "Erros";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar o dashboard: " + ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            CarregarDashboard();
            CarregarLista();
        }

        private void CarregarLista()
        {
            try
            {
                SimeService service = new SimeService();
                dgvOcorrencias.DataSource = service.Localizar(txtBusca.Text.Trim());

                dgvOcorrencias.Columns["PerfilUsuario"].Visible = false;
                dgvOcorrencias.Columns["Id"].HeaderText = "Código";
                dgvOcorrencias.Columns["Maquina"].HeaderText = "Máquina";
                dgvOcorrencias.Columns["DataHora"].HeaderText = "Data e Hora";
                dgvOcorrencias.Columns["Colaborador"].HeaderText = "Operador";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar: " + ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            CarregarLista();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtBusca.Clear();
            CarregarLista();
        }

        private void btnDetalhes_Click(object sender, EventArgs e)
        {
            AbrirDetalhes();
        }

        private void dgvOcorrencias_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                AbrirDetalhes();
            }
        }

        private void AbrirDetalhes()
        {
            if (dgvOcorrencias.CurrentRow == null)
            {
                MessageBox.Show("Selecione uma ocorrência na lista.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Ocorrencia ocorrencia = (Ocorrencia)dgvOcorrencias.CurrentRow.DataBoundItem;

            FormDetalhes telaDetalhes = new FormDetalhes(ocorrencia);
            if (telaDetalhes.ShowDialog() == DialogResult.OK)
            {
                CarregarDashboard();
                CarregarLista();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
