using SimeDesktop.Models;
using SimeDesktop.Services;

namespace SimeDesktop
{
    public partial class FormDetalhes : Form
    {
        public FormDetalhes(Ocorrencia ocorrencia)
        {
            InitializeComponent();

            txtCodigo.Text = ocorrencia.Id.ToString();
            txtMaquina.Text = ocorrencia.Maquina;
            txtErro.Text = ocorrencia.Erro;
            txtOperador.Text = ocorrencia.Colaborador;
            txtDataHora.Text = ocorrencia.DataHora.ToString("dd/MM/yyyy HH:mm:ss");
            cmbStatus.SelectedItem = ocorrencia.Status;
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbStatus.SelectedItem == null)
                {
                    MessageBox.Show("Selecione o status.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                SimeService service = new SimeService();
                service.AlterarStatus(Convert.ToInt32(txtCodigo.Text), cmbStatus.SelectedItem.ToString());

                MessageBox.Show("Status alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
