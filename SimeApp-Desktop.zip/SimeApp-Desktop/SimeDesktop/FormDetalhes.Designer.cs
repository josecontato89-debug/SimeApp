namespace SimeDesktop
{
    partial class FormDetalhes
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            pnlTopo = new Panel();
            lblTitulo = new Label();
            lblCodigo = new Label();
            txtCodigo = new TextBox();
            lblMaquina = new Label();
            txtMaquina = new TextBox();
            lblErro = new Label();
            txtErro = new TextBox();
            lblOperador = new Label();
            txtOperador = new TextBox();
            lblDataHora = new Label();
            txtDataHora = new TextBox();
            lblStatus = new Label();
            cmbStatus = new ComboBox();
            btnAtualizar = new Button();
            btnCancelar = new Button();
            pnlTopo.SuspendLayout();
            SuspendLayout();
            pnlTopo.BackColor = Color.FromArgb(33, 150, 243);
            pnlTopo.Controls.Add(lblTitulo);
            pnlTopo.Dock = DockStyle.Top;
            pnlTopo.Location = new Point(0, 0);
            pnlTopo.Name = "pnlTopo";
            pnlTopo.Size = new Size(420, 50);
            pnlTopo.TabIndex = 0;
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblTitulo.ForeColor = Color.White;
            lblTitulo.Location = new Point(15, 13);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(205, 25);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Detalhes da Ocorrência";
            lblCodigo.AutoSize = true;
            lblCodigo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCodigo.Location = new Point(20, 65);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(60, 19);
            lblCodigo.TabIndex = 1;
            lblCodigo.Text = "Código:";
            txtCodigo.Font = new Font("Segoe UI", 11F);
            txtCodigo.Location = new Point(20, 87);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.ReadOnly = true;
            txtCodigo.Size = new Size(100, 27);
            txtCodigo.TabIndex = 2;
            lblMaquina.AutoSize = true;
            lblMaquina.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblMaquina.Location = new Point(140, 65);
            lblMaquina.Name = "lblMaquina";
            lblMaquina.Size = new Size(72, 19);
            lblMaquina.TabIndex = 3;
            lblMaquina.Text = "Máquina:";
            txtMaquina.Font = new Font("Segoe UI", 11F);
            txtMaquina.Location = new Point(140, 87);
            txtMaquina.Name = "txtMaquina";
            txtMaquina.ReadOnly = true;
            txtMaquina.Size = new Size(260, 27);
            txtMaquina.TabIndex = 4;
            lblErro.AutoSize = true;
            lblErro.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblErro.Location = new Point(20, 122);
            lblErro.Name = "lblErro";
            lblErro.Size = new Size(203, 19);
            lblErro.TabIndex = 5;
            lblErro.Text = "Código / Descrição do Erro:";
            txtErro.Font = new Font("Segoe UI", 11F);
            txtErro.Location = new Point(20, 144);
            txtErro.Multiline = true;
            txtErro.Name = "txtErro";
            txtErro.ReadOnly = true;
            txtErro.Size = new Size(380, 70);
            txtErro.TabIndex = 6;
            lblOperador.AutoSize = true;
            lblOperador.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblOperador.Location = new Point(20, 225);
            lblOperador.Name = "lblOperador";
            lblOperador.Size = new Size(76, 19);
            lblOperador.TabIndex = 7;
            lblOperador.Text = "Operador:";
            txtOperador.Font = new Font("Segoe UI", 11F);
            txtOperador.Location = new Point(20, 247);
            txtOperador.Name = "txtOperador";
            txtOperador.ReadOnly = true;
            txtOperador.Size = new Size(380, 27);
            txtOperador.TabIndex = 8;
            lblDataHora.AutoSize = true;
            lblDataHora.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblDataHora.Location = new Point(20, 282);
            lblDataHora.Name = "lblDataHora";
            lblDataHora.Size = new Size(94, 19);
            lblDataHora.TabIndex = 9;
            lblDataHora.Text = "Data e Hora:";
            txtDataHora.Font = new Font("Segoe UI", 11F);
            txtDataHora.Location = new Point(20, 304);
            txtDataHora.Name = "txtDataHora";
            txtDataHora.ReadOnly = true;
            txtDataHora.Size = new Size(380, 27);
            txtDataHora.TabIndex = 10;
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblStatus.Location = new Point(20, 339);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(54, 19);
            lblStatus.TabIndex = 11;
            lblStatus.Text = "Status:";
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.Font = new Font("Segoe UI", 11F);
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Items.AddRange(new object[] { "pendente", "resolvido" });
            cmbStatus.Location = new Point(20, 361);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(200, 28);
            cmbStatus.TabIndex = 12;
            btnAtualizar.BackColor = Color.FromArgb(33, 150, 243);
            btnAtualizar.FlatAppearance.BorderSize = 0;
            btnAtualizar.FlatStyle = FlatStyle.Flat;
            btnAtualizar.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAtualizar.ForeColor = Color.White;
            btnAtualizar.Location = new Point(20, 410);
            btnAtualizar.Name = "btnAtualizar";
            btnAtualizar.Size = new Size(185, 40);
            btnAtualizar.TabIndex = 13;
            btnAtualizar.Text = "Atualizar";
            btnAtualizar.UseVisualStyleBackColor = false;
            btnAtualizar.Click += btnAtualizar_Click;
            btnCancelar.BackColor = Color.Gray;
            btnCancelar.FlatAppearance.BorderSize = 0;
            btnCancelar.FlatStyle = FlatStyle.Flat;
            btnCancelar.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCancelar.ForeColor = Color.White;
            btnCancelar.Location = new Point(215, 410);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(185, 40);
            btnCancelar.TabIndex = 14;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = false;
            btnCancelar.Click += btnCancelar_Click;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(420, 470);
            Controls.Add(pnlTopo);
            Controls.Add(lblCodigo);
            Controls.Add(txtCodigo);
            Controls.Add(lblMaquina);
            Controls.Add(txtMaquina);
            Controls.Add(lblErro);
            Controls.Add(txtErro);
            Controls.Add(lblOperador);
            Controls.Add(txtOperador);
            Controls.Add(lblDataHora);
            Controls.Add(txtDataHora);
            Controls.Add(lblStatus);
            Controls.Add(cmbStatus);
            Controls.Add(btnAtualizar);
            Controls.Add(btnCancelar);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FormDetalhes";
            StartPosition = FormStartPosition.CenterParent;
            Text = "SIME - Detalhes da Ocorrência";
            pnlTopo.ResumeLayout(false);
            pnlTopo.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlTopo;
        private Label lblTitulo;
        private Label lblCodigo;
        private TextBox txtCodigo;
        private Label lblMaquina;
        private TextBox txtMaquina;
        private Label lblErro;
        private TextBox txtErro;
        private Label lblOperador;
        private TextBox txtOperador;
        private Label lblDataHora;
        private TextBox txtDataHora;
        private Label lblStatus;
        private ComboBox cmbStatus;
        private Button btnAtualizar;
        private Button btnCancelar;
    }
}
