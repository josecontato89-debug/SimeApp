namespace SimeDesktop
{
    partial class FormCadastro
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pnlTopo = new Panel();
            lblTituloOperador = new Label();
            lblOperador = new Label();
            btnSair = new Button();
            lblMaquina = new Label();
            cmbMaquina = new ComboBox();
            lblLegenda = new Label();
            lblErro = new Label();
            txtErro = new TextBox();
            lblTituloData = new Label();
            lblDataHora = new Label();
            lblTituloStatus = new Label();
            lblStatus = new Label();
            btnInserir = new Button();
            btnCancelar = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            pnlTopo.SuspendLayout();
            SuspendLayout();
            pnlTopo.BackColor = Color.FromArgb(33, 150, 243);
            pnlTopo.Controls.Add(lblTituloOperador);
            pnlTopo.Controls.Add(lblOperador);
            pnlTopo.Controls.Add(btnSair);
            pnlTopo.Dock = DockStyle.Top;
            pnlTopo.Location = new Point(0, 0);
            pnlTopo.Name = "pnlTopo";
            pnlTopo.Size = new Size(480, 70);
            pnlTopo.TabIndex = 0;
            lblTituloOperador.AutoSize = true;
            lblTituloOperador.ForeColor = Color.White;
            lblTituloOperador.Location = new Point(15, 10);
            lblTituloOperador.Name = "lblTituloOperador";
            lblTituloOperador.Size = new Size(60, 15);
            lblTituloOperador.TabIndex = 0;
            lblTituloOperador.Text = "Operador:";
            lblOperador.AutoSize = true;
            lblOperador.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblOperador.ForeColor = Color.White;
            lblOperador.Location = new Point(15, 30);
            lblOperador.Name = "lblOperador";
            lblOperador.Size = new Size(30, 25);
            lblOperador.TabIndex = 1;
            lblOperador.Text = "-";
            btnSair.BackColor = Color.FromArgb(244, 67, 54);
            btnSair.FlatAppearance.BorderSize = 0;
            btnSair.FlatStyle = FlatStyle.Flat;
            btnSair.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSair.ForeColor = Color.White;
            btnSair.Location = new Point(375, 17);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(90, 36);
            btnSair.TabIndex = 2;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += btnSair_Click;
            lblMaquina.AutoSize = true;
            lblMaquina.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblMaquina.Location = new Point(20, 85);
            lblMaquina.Name = "lblMaquina";
            lblMaquina.Size = new Size(72, 19);
            lblMaquina.TabIndex = 1;
            lblMaquina.Text = "Máquina:";
            cmbMaquina.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMaquina.Font = new Font("Segoe UI", 11F);
            cmbMaquina.FormattingEnabled = true;
            cmbMaquina.Items.AddRange(new object[] { "tcnc01", "fcnc01", "cpr01", "sld01", "etmp01" });
            cmbMaquina.Location = new Point(20, 107);
            cmbMaquina.Name = "cmbMaquina";
            cmbMaquina.Size = new Size(200, 28);
            cmbMaquina.TabIndex = 2;
            lblLegenda.ForeColor = Color.Gray;
            lblLegenda.Location = new Point(230, 103);
            lblLegenda.Name = "lblLegenda";
            lblLegenda.Size = new Size(235, 40);
            lblLegenda.TabIndex = 3;
            lblLegenda.Text = "tcnc01 = Torno CNC | fcnc01 = Fresadora CNC | cpr01 = Cortadora Plasma | sld01 = Solda | etmp01 = Estamparia";
            lblErro.AutoSize = true;
            lblErro.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblErro.Location = new Point(20, 152);
            lblErro.Name = "lblErro";
            lblErro.Size = new Size(203, 19);
            lblErro.TabIndex = 4;
            lblErro.Text = "Código / Descrição do Erro:";
            txtErro.Font = new Font("Segoe UI", 11F);
            txtErro.Location = new Point(20, 174);
            txtErro.MaxLength = 200;
            txtErro.Multiline = true;
            txtErro.Name = "txtErro";
            txtErro.PlaceholderText = "Digite o código ou a descrição do erro aqui...";
            txtErro.Size = new Size(445, 90);
            txtErro.TabIndex = 5;
            lblTituloData.AutoSize = true;
            lblTituloData.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblTituloData.Location = new Point(20, 277);
            lblTituloData.Name = "lblTituloData";
            lblTituloData.Size = new Size(94, 19);
            lblTituloData.TabIndex = 6;
            lblTituloData.Text = "Data e Hora:";
            lblDataHora.AutoSize = true;
            lblDataHora.Font = new Font("Segoe UI", 12F);
            lblDataHora.Location = new Point(20, 299);
            lblDataHora.Name = "lblDataHora";
            lblDataHora.Size = new Size(30, 21);
            lblDataHora.TabIndex = 7;
            lblDataHora.Text = "--";
            lblTituloStatus.AutoSize = true;
            lblTituloStatus.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblTituloStatus.Location = new Point(260, 277);
            lblTituloStatus.Name = "lblTituloStatus";
            lblTituloStatus.Size = new Size(54, 19);
            lblTituloStatus.TabIndex = 8;
            lblTituloStatus.Text = "Status:";
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 12F);
            lblStatus.ForeColor = Color.FromArgb(255, 152, 0);
            lblStatus.Location = new Point(260, 299);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(70, 21);
            lblStatus.TabIndex = 9;
            lblStatus.Text = "pendente";
            btnInserir.BackColor = Color.FromArgb(76, 175, 80);
            btnInserir.FlatAppearance.BorderSize = 0;
            btnInserir.FlatStyle = FlatStyle.Flat;
            btnInserir.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnInserir.ForeColor = Color.White;
            btnInserir.Location = new Point(20, 345);
            btnInserir.Name = "btnInserir";
            btnInserir.Size = new Size(215, 40);
            btnInserir.TabIndex = 10;
            btnInserir.Text = "Inserir";
            btnInserir.UseVisualStyleBackColor = false;
            btnInserir.Click += btnInserir_Click;
            btnCancelar.BackColor = Color.Gray;
            btnCancelar.FlatAppearance.BorderSize = 0;
            btnCancelar.FlatStyle = FlatStyle.Flat;
            btnCancelar.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCancelar.ForeColor = Color.White;
            btnCancelar.Location = new Point(250, 345);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(215, 40);
            btnCancelar.TabIndex = 11;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = false;
            btnCancelar.Click += btnCancelar_Click;
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(480, 405);
            Controls.Add(pnlTopo);
            Controls.Add(lblMaquina);
            Controls.Add(cmbMaquina);
            Controls.Add(lblLegenda);
            Controls.Add(lblErro);
            Controls.Add(txtErro);
            Controls.Add(lblTituloData);
            Controls.Add(lblDataHora);
            Controls.Add(lblTituloStatus);
            Controls.Add(lblStatus);
            Controls.Add(btnInserir);
            Controls.Add(btnCancelar);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FormCadastro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SIME - Registrar Ocorrência";
            pnlTopo.ResumeLayout(false);
            pnlTopo.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlTopo;
        private Label lblTituloOperador;
        private Label lblOperador;
        private Button btnSair;
        private Label lblMaquina;
        private ComboBox cmbMaquina;
        private Label lblLegenda;
        private Label lblErro;
        private TextBox txtErro;
        private Label lblTituloData;
        private Label lblDataHora;
        private Label lblTituloStatus;
        private Label lblStatus;
        private Button btnInserir;
        private Button btnCancelar;
        private System.Windows.Forms.Timer timer1;
    }
}
