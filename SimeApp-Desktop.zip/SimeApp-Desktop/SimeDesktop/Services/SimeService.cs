using MySqlConnector;
using SimeDesktop.Models;

namespace SimeDesktop.Services
{
    public class SimeService
    {
        public static string Conexao = "Server=sql.freedb.tech;Port=3306;Database=freedb_Y30frC4a;Uid=u_ZD4sap;Pwd=RSOdxiOhphZb;SslMode=None;AllowPublicKeyRetrieval=True;";

        public Usuario FazerLogin(string login, string senha)
        {
            List<Usuario> usuarios = new List<Usuario>();
            usuarios.Add(new Usuario { Login = "operador", Senha = "123", Nome = "João Operador", Perfil = "Operador" });
            usuarios.Add(new Usuario { Login = "operador2", Senha = "123", Nome = "Maria Operadora", Perfil = "Operador" });
            usuarios.Add(new Usuario { Login = "supervisor", Senha = "123", Nome = "Carlos Supervisor", Perfil = "Supervisor" });

            foreach (Usuario u in usuarios)
            {
                if (u.Login == login && u.Senha == senha)
                {
                    return u;
                }
            }

            return null;
        }

        public void Inserir(Ocorrencia ocorrencia)
        {
            if (string.IsNullOrWhiteSpace(ocorrencia.Maquina))
                throw new Exception("A máquina é obrigatória!");

            if (string.IsNullOrWhiteSpace(ocorrencia.Erro))
                throw new Exception("O código ou a descrição do erro é obrigatório!");

            using (MySqlConnection conn = new MySqlConnection(Conexao))
            {
                conn.Open();

                string sql = "INSERT INTO sime (colaborador, perfil_usuario, maquina, status, erro, data_hora) " +
                             "VALUES (@colaborador, @perfil, @maquina, @status, @erro, @data_hora)";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@colaborador", ocorrencia.Colaborador);
                cmd.Parameters.AddWithValue("@perfil", ocorrencia.PerfilUsuario);
                cmd.Parameters.AddWithValue("@maquina", ocorrencia.Maquina);
                cmd.Parameters.AddWithValue("@status", ocorrencia.Status);
                cmd.Parameters.AddWithValue("@erro", ocorrencia.Erro);
                cmd.Parameters.AddWithValue("@data_hora", ocorrencia.DataHora);

                cmd.ExecuteNonQuery();
            }
        }

        public List<Ocorrencia> Listar()
        {
            return Localizar("");
        }

        public List<Ocorrencia> Localizar(string maquina)
        {
            List<Ocorrencia> lista = new List<Ocorrencia>();

            using (MySqlConnection conn = new MySqlConnection(Conexao))
            {
                conn.Open();

                string sql = "SELECT * FROM sime WHERE maquina LIKE @busca ORDER BY data_hora DESC";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@busca", "%" + maquina + "%");

                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Ocorrencia ocorrencia = new Ocorrencia();
                    ocorrencia.Id = reader.GetInt32("id");
                    ocorrencia.Colaborador = reader.GetString("colaborador");
                    ocorrencia.PerfilUsuario = reader.GetString("perfil_usuario");
                    ocorrencia.Maquina = reader.GetString("maquina");
                    ocorrencia.Status = reader.GetString("status");
                    ocorrencia.Erro = reader.GetString("erro");
                    ocorrencia.DataHora = reader.GetDateTime("data_hora");
                    lista.Add(ocorrencia);
                }

                reader.Close();
            }

            return lista;
        }

        public List<ErrosMes> ErrosPorMes()
        {
            List<ErrosMes> lista = new List<ErrosMes>();

            using (MySqlConnection conn = new MySqlConnection(Conexao))
            {
                conn.Open();

                string sql = "SELECT DATE_FORMAT(data_hora, '%m/%Y') AS mes, " +
                             "COUNT(*) AS quantidade, " +
                             "SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) AS pendentes " +
                             "FROM sime " +
                             "GROUP BY DATE_FORMAT(data_hora, '%Y-%m'), DATE_FORMAT(data_hora, '%m/%Y') " +
                             "ORDER BY DATE_FORMAT(data_hora, '%Y-%m') DESC";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ErrosMes item = new ErrosMes();
                    item.Mes = reader.GetString("mes");
                    item.Quantidade = Convert.ToInt32(reader["quantidade"]);
                    item.Pendentes = Convert.ToInt32(reader["pendentes"]);
                    lista.Add(item);
                }

                reader.Close();
            }

            return lista;
        }

        public void AlterarStatus(int id, string novoStatus)
        {
            if (id <= 0)
                throw new Exception("ID inválido para alteração!");

            using (MySqlConnection conn = new MySqlConnection(Conexao))
            {
                conn.Open();

                string sql = "UPDATE sime SET status = @status WHERE id = @id";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@status", novoStatus);
                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
