using SimeDesktop.Models;
using SimeDesktop.Services;

namespace SimeDesktop
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string login = txtUsuario.Text.Trim().ToLower();
            string senha = txtSenha.Text;

            if (login == "" || senha == "")
            {
                MessageBox.Show("Informe o usuário e a senha.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SimeService service = new SimeService();
            Usuario usuario = service.FazerLogin(login, senha);

            if (usuario == null)
            {
                MessageBox.Show("Usuário ou senha inválidos.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.Hide();

            if (usuario.Perfil == "Supervisor")
            {
                FormPrincipal telaPrincipal = new FormPrincipal(usuario);
                telaPrincipal.ShowDialog();
            }
            else
            {
                FormCadastro telaCadastro = new FormCadastro(usuario);
                telaCadastro.ShowDialog();
            }

            txtSenha.Clear();
            this.Show();
        }
    }
}
