namespace SimeDesktop
{
    partial class FormLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            pnlTopo = new Panel();
            lblTitulo = new Label();
            lblSubtitulo = new Label();
            lblUsuario = new Label();
            txtUsuario = new TextBox();
            lblSenha = new Label();
            txtSenha = new TextBox();
            btnEntrar = new Button();
            pnlTopo.SuspendLayout();
            SuspendLayout();
            pnlTopo.BackColor = Color.FromArgb(33, 150, 243);
            pnlTopo.Controls.Add(lblTitulo);
            pnlTopo.Controls.Add(lblSubtitulo);
            pnlTopo.Dock = DockStyle.Top;
            pnlTopo.Location = new Point(0, 0);
            pnlTopo.Name = "pnlTopo";
            pnlTopo.Size = new Size(360, 90);
            pnlTopo.TabIndex = 0;
            lblTitulo.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblTitulo.ForeColor = Color.White;
            lblTitulo.Location = new Point(0, 8);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(360, 45);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "SIME";
            lblTitulo.TextAlign = ContentAlignment.MiddleCenter;
            lblSubtitulo.ForeColor = Color.White;
            lblSubtitulo.Location = new Point(0, 55);
            lblSubtitulo.Name = "lblSubtitulo";
            lblSubtitulo.Size = new Size(360, 20);
            lblSubtitulo.TabIndex = 1;
            lblSubtitulo.Text = "Sistema de Monitoramento de Erros Industriais";
            lblSubtitulo.TextAlign = ContentAlignment.MiddleCenter;
            lblUsuario.AutoSize = true;
            lblUsuario.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblUsuario.Location = new Point(30, 110);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(63, 19);
            lblUsuario.TabIndex = 1;
            lblUsuario.Text = "Usuário:";
            txtUsuario.Font = new Font("Segoe UI", 11F);
            txtUsuario.Location = new Point(30, 132);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.PlaceholderText = "Ex: operador ou supervisor";
            txtUsuario.Size = new Size(300, 27);
            txtUsuario.TabIndex = 2;
            lblSenha.AutoSize = true;
            lblSenha.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblSenha.Location = new Point(30, 172);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(52, 19);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Senha:";
            txtSenha.Font = new Font("Segoe UI", 11F);
            txtSenha.Location = new Point(30, 194);
            txtSenha.Name = "txtSenha";
            txtSenha.PasswordChar = '*';
            txtSenha.PlaceholderText = "Digite a senha";
            txtSenha.Size = new Size(300, 27);
            txtSenha.TabIndex = 4;
            btnEntrar.BackColor = Color.FromArgb(33, 150, 243);
            btnEntrar.FlatAppearance.BorderSize = 0;
            btnEntrar.FlatStyle = FlatStyle.Flat;
            btnEntrar.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnEntrar.ForeColor = Color.White;
            btnEntrar.Location = new Point(30, 245);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(300, 40);
            btnEntrar.TabIndex = 5;
            btnEntrar.Text = "Entrar";
            btnEntrar.UseVisualStyleBackColor = false;
            btnEntrar.Click += btnEntrar_Click;
            AcceptButton = btnEntrar;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(360, 310);
            Controls.Add(pnlTopo);
            Controls.Add(lblUsuario);
            Controls.Add(txtUsuario);
            Controls.Add(lblSenha);
            Controls.Add(txtSenha);
            Controls.Add(btnEntrar);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FormLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SIME - Login";
            pnlTopo.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlTopo;
        private Label lblTitulo;
        private Label lblSubtitulo;
        private Label lblUsuario;
        private TextBox txtUsuario;
        private Label lblSenha;
        private TextBox txtSenha;
        private Button btnEntrar;
    }
}
