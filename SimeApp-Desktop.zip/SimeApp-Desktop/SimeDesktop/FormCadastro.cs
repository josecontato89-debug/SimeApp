using SimeDesktop.Models;
using SimeDesktop.Services;

namespace SimeDesktop
{
    public partial class FormCadastro : Form
    {
        Usuario usuarioLogado;

        public FormCadastro(Usuario usuario)
        {
            InitializeComponent();

            usuarioLogado = usuario;

            lblOperador.Text = usuarioLogado.Nome;
            lblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbMaquina.SelectedItem == null)
                {
                    MessageBox.Show("Selecione a máquina.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Ocorrencia ocorrencia = new Ocorrencia
                {
                    Maquina = cmbMaquina.SelectedItem.ToString(),
                    Erro = txtErro.Text.Trim(),
                    DataHora = DateTime.Now,
                    Colaborador = usuarioLogado.Nome,
                    PerfilUsuario = usuarioLogado.Perfil,
                    Status = "pendente"
                };

                SimeService service = new SimeService();
                service.Inserir(ocorrencia);

                MessageBox.Show("Ocorrência registrada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void LimparCampos()
        {
            cmbMaquina.SelectedIndex = -1;
            txtErro.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
