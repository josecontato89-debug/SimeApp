# SIME - App Mobile (Xamarin.Forms / Android)

Sistema de Monitoramento de Erros Industriais - versão celular.

## Como rodar
1. Abra o `Simeapp.sln` no Visual Studio 2022 (carga de trabalho "Desenvolvimento para dispositivos móveis com .NET").
2. Rode o `sime.sql` no phpMyAdmin do FreeDB (só na primeira vez).
3. Em `SimeApp/Services/SimeService.cs`, troque `SEU_USUARIO` e `SUA_SENHA` pelos dados do FreeDB.
4. Escolha o projeto `SimeApp.Android` como inicialização e rode no emulador ou no celular.

## Usuários
| Usuário | Senha | Perfil |
|---|---|---|
| operador | 123 | Operador |
| operador2 | 123 | Operador |
| supervisor | 123 | Supervisor |

## Organização
- `Models/` - Ocorrencia, Usuario, ErrosMes
- `Services/SimeService.cs` - login e acesso ao banco (Inserir, Listar, Localizar, ErrosPorMes, AlterarStatus)
- `Views/`
  - **PageLogin:** usuário e senha.
  - **PageCadastro:** (Operador) escolhe a máquina e digita o erro. Nome, data/hora e status "pendente" são automáticos.
  - **PagePrincipal:** (Supervisor) abas Dashboard e Ocorrências.
  - **PageHome:** totais (total, pendentes, resolvidos) e gráfico de erros por mês.
  - **PageListar:** lista com busca por máquina. Toque numa ocorrência para abrir os detalhes.
  - **PageDetalhes:** mostra a ocorrência e permite alterar o status.

## Sincronização
O app Desktop usa o mesmo banco. Registre um erro no Mobile, clique em "Atualizar" no Desktop e ele aparece lá. Mude o status no Desktop e puxe a lista para baixo no Mobile para ver a mudança.
