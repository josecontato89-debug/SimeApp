namespace SimeApp.Models
{
    public class Usuario
    {
        public string Login { get; set; }
        public string Senha { get; set; }
        public string Nome { get; set; }
        public string Perfil { get; set; }
    }
}
