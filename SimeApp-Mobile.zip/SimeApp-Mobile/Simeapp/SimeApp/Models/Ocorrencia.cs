using System;

namespace SimeApp.Models
{
    public class Ocorrencia
    {
        public int Id { get; set; }
        public string Maquina { get; set; }
        public string Erro { get; set; }
        public DateTime DataHora { get; set; }
        public string Colaborador { get; set; }
        public string PerfilUsuario { get; set; }
        public string Status { get; set; }
    }
}
