using Xamarin.Forms;
using SimeApp.Views;

namespace SimeApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new PageLogin();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
