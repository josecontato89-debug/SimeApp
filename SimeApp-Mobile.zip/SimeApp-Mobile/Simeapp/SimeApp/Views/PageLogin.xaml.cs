using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SimeApp.Models;
using SimeApp.Services;

namespace SimeApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageLogin : ContentPage
    {
        public PageLogin()
        {
            InitializeComponent();
        }

        private async void btEntrar_Clicked(object sender, EventArgs e)
        {
            string login = txtUsuario.Text;
            string senha = txtSenha.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(senha))
            {
                await DisplayAlert("Atenção", "Informe o usuário e a senha.", "OK");
                return;
            }

            SimeService service = new SimeService();
            Usuario usuario = service.FazerLogin(login.Trim().ToLower(), senha);

            if (usuario == null)
            {
                await DisplayAlert("Login", "Usuário ou senha inválidos.", "OK");
                return;
            }

            if (usuario.Perfil == "Supervisor")
            {
                Application.Current.MainPage = new PagePrincipal(usuario);
            }
            else
            {
                NavigationPage navegacao = new NavigationPage(new PageCadastro(usuario));
                navegacao.BarBackgroundColor = Color.FromHex("#2196F3");
                navegacao.BarTextColor = Color.White;
                Application.Current.MainPage = navegacao;
            }
        }
    }
}
