using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SimeApp.Models;

namespace SimeApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PagePrincipal : TabbedPage
    {
        public PagePrincipal(Usuario usuario)
        {
            InitializeComponent();

            NavigationPage abaDashboard = new NavigationPage(new PageHome(usuario));
            abaDashboard.Title = "Dashboard";
            abaDashboard.BarBackgroundColor = Color.FromHex("#2196F3");
            abaDashboard.BarTextColor = Color.White;

            NavigationPage abaOcorrencias = new NavigationPage(new PageListar());
            abaOcorrencias.Title = "Ocorrências";
            abaOcorrencias.BarBackgroundColor = Color.FromHex("#2196F3");
            abaOcorrencias.BarTextColor = Color.White;

            Children.Add(abaDashboard);
            Children.Add(abaOcorrencias);
        }
    }
}
