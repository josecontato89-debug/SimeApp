using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SimeApp.Models;
using SimeApp.Services;

namespace SimeApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageListar : ContentPage
    {
        public PageListar()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            CarregarLista();
        }

        private async void CarregarLista()
        {
            try
            {
                SimeService service = new SimeService();
                lstOcorrencias.ItemsSource = await service.Localizar(txtBusca.Text ?? "");
            }
            catch (Exception ex)
            {
                string detalhe = ex.ToString();
                if (detalhe.Length > 900) detalhe = detalhe.Substring(0, 900);
                await DisplayAlert("Atenção", "Erro ao listar: " + detalhe, "OK");
            }

            lstOcorrencias.IsRefreshing = false;
        }

        private void txtBusca_SearchButtonPressed(object sender, EventArgs e)
        {
            CarregarLista();
        }

        private void txtBusca_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(e.NewTextValue))
            {
                CarregarLista();
            }
        }

        private void lstOcorrencias_Refreshing(object sender, EventArgs e)
        {
            CarregarLista();
        }

        private async void lstOcorrencias_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            Ocorrencia ocorrencia = (Ocorrencia)e.Item;
            lstOcorrencias.SelectedItem = null;

            await Navigation.PushAsync(new PageDetalhes(ocorrencia));
        }

        private void btSair_Clicked(object sender, EventArgs e)
        {
            Application.Current.MainPage = new PageLogin();
        }
    }
}
