using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SimeApp.Models;
using SimeApp.Services;

namespace SimeApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageCadastro : ContentPage
    {
        Usuario usuarioLogado;
        bool relogioLigado = false;

        public PageCadastro(Usuario usuario)
        {
            InitializeComponent();

            usuarioLogado = usuario;

            lblOperador.Text = usuarioLogado.Nome;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            relogioLigado = true;
            lblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                lblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                return relogioLigado;
            });
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            relogioLigado = false;
        }

        private async void btSalvar_Clicked(object sender, EventArgs e)
        {
            bool salvou = false;

            try
            {
                if (pckMaquina.SelectedItem == null)
                {
                    await DisplayAlert("Atenção", "Selecione a máquina.", "OK");
                    return;
                }

                Ocorrencia ocorrencia = new Ocorrencia
                {
                    Maquina = pckMaquina.SelectedItem.ToString(),
                    Erro = txtErro.Text?.Trim() ?? string.Empty,
                    DataHora = DateTime.Now,
                    Colaborador = usuarioLogado.Nome,
                    PerfilUsuario = usuarioLogado.Perfil,
                    Status = "pendente"
                };

                btSalvar.IsEnabled = false;

                SimeService service = new SimeService();
                await service.Inserir(ocorrencia);
                salvou = true;
            }
            catch (Exception ex)
            {
                string detalhe = ex.ToString();
                if (detalhe.Length > 900) detalhe = detalhe.Substring(0, 900);
                await DisplayAlert("Atenção", detalhe, "OK");
            }
            finally
            {
                btSalvar.IsEnabled = true;
            }

            if (salvou)
            {
                await DisplayAlert("Sucesso", "Ocorrência registrada com sucesso!", "OK");
                LimparCampos();
            }
        }

        private void btCancelar_Clicked(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void LimparCampos()
        {
            txtErro.Text = string.Empty;

            try
            {
                pckMaquina.SelectedItem = null;
            }
            catch (Exception)
            {
            }
        }

        private void btSair_Clicked(object sender, EventArgs e)
        {
            Application.Current.MainPage = new PageLogin();
        }
    }
}
