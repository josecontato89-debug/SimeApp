using System;
using System.Collections.Generic;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SimeApp.Models;
using SimeApp.Services;

namespace SimeApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageHome : ContentPage
    {
        List<Ocorrencia> todas = new List<Ocorrencia>();
        string filtroAtual = null;

        public PageHome(Usuario usuario)
        {
            InitializeComponent();
            lblSupervisor.Text = usuario.Nome;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            CarregarDados();
        }

        private async void CarregarDados()
        {
            try
            {
                SimeService service = new SimeService();

                List<Ocorrencia> ocorrencias = await service.Listar();
                int pendentes = 0;
                int resolvidos = 0;
                foreach (Ocorrencia o in ocorrencias)
                {
                    if (o.Status == "pendente")
                        pendentes++;
                    else
                        resolvidos++;
                }
                todas = ocorrencias;
                lblTotal.Text = ocorrencias.Count.ToString();
                lblPendentes.Text = pendentes.ToString();
                lblResolvidos.Text = resolvidos.ToString();

                List<ErrosMes> meses = await service.ErrosPorMes();
                int maior = 1;
                foreach (ErrosMes m in meses)
                {
                    if (m.Quantidade > maior)
                        maior = m.Quantidade;
                }
                foreach (ErrosMes m in meses)
                {
                    m.Percentual = (double)m.Quantidade / maior;
                }
                lstMeses.ItemsSource = meses;

                AplicarFiltro();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Atenção", "Erro ao carregar o dashboard: " + ex.Message, "OK");
            }
        }

        private void cardTotal_Tapped(object sender, EventArgs e)
        {
            AlternarFiltro("total");
        }

        private void cardPendentes_Tapped(object sender, EventArgs e)
        {
            AlternarFiltro("pendente");
        }

        private void cardResolvidos_Tapped(object sender, EventArgs e)
        {
            AlternarFiltro("resolvido");
        }

        private void AlternarFiltro(string filtro)
        {
            filtroAtual = (filtroAtual == filtro) ? null : filtro;
            AplicarFiltro();
        }

        private void AplicarFiltro()
        {
            cardTotal.Opacity = (filtroAtual == null || filtroAtual == "total") ? 1 : 0.5;
            cardPendentes.Opacity = (filtroAtual == null || filtroAtual == "pendente") ? 1 : 0.5;
            cardResolvidos.Opacity = (filtroAtual == null || filtroAtual == "resolvido") ? 1 : 0.5;

            if (filtroAtual == null)
            {
                areaLista.IsVisible = false;
                areaMeses.IsVisible = true;
                lblDica.Text = "Toque em Total, Pendentes ou Resolvidos para ver as ocorrências.";
                return;
            }

            List<Ocorrencia> filtradas = new List<Ocorrencia>();
            foreach (Ocorrencia o in todas)
            {
                bool pendente = o.Status == "pendente";
                if (filtroAtual == "total" ||
                    (filtroAtual == "pendente" && pendente) ||
                    (filtroAtual == "resolvido" && !pendente))
                {
                    filtradas.Add(o);
                }
            }

            string nome = filtroAtual == "total" ? "Todas as ocorrências"
                        : filtroAtual == "pendente" ? "Ocorrências pendentes"
                        : "Ocorrências resolvidas";
            lblTituloLista.Text = nome + " (" + filtradas.Count + ")";
            lstFiltrada.ItemsSource = filtradas;

            lblDica.Text = "Toque numa ocorrência para ver os detalhes ou toque no card de novo para fechar.";
            areaMeses.IsVisible = false;
            areaLista.IsVisible = true;
        }

        private async void lstFiltrada_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            Ocorrencia ocorrencia = (Ocorrencia)e.Item;
            lstFiltrada.SelectedItem = null;
            await Navigation.PushAsync(new PageDetalhes(ocorrencia));
        }

        private void btAtualizar_Clicked(object sender, EventArgs e)
        {
            CarregarDados();
        }

        private void btSair_Clicked(object sender, EventArgs e)
        {
            Application.Current.MainPage = new PageLogin();
        }
    }
}
