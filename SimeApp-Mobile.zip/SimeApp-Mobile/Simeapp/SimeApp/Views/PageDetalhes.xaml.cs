using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SimeApp.Models;
using SimeApp.Services;

namespace SimeApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageDetalhes : ContentPage
    {
        public PageDetalhes(Ocorrencia ocorrencia)
        {
            InitializeComponent();

            txtCodigo.Text = ocorrencia.Id.ToString();
            txtMaquina.Text = ocorrencia.Maquina;
            txtErro.Text = ocorrencia.Erro;
            txtOperador.Text = ocorrencia.Colaborador;
            txtDataHora.Text = ocorrencia.DataHora.ToString("dd/MM/yyyy HH:mm:ss");
            pckStatus.SelectedItem = ocorrencia.Status;
        }

        private async void btAtualizar_Clicked(object sender, EventArgs e)
        {
            try
            {
                if (pckStatus.SelectedItem == null)
                {
                    await DisplayAlert("Atenção", "Selecione o status.", "OK");
                    return;
                }

                SimeService service = new SimeService();
                await service.AlterarStatus(Convert.ToInt32(txtCodigo.Text), pckStatus.SelectedItem.ToString());

                await DisplayAlert("Sucesso", "Status alterado com sucesso!", "OK");
                await Navigation.PopAsync();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Atenção", ex.Message, "OK");
            }
        }

        private async void btCancelar_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}
